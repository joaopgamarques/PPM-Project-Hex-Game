package Project

object Cells extends Enumeration {
  type Cell = Value
  val Red, Blue, Empty = Value
}