package Project

enum FirstPlayer {
  case User, Computer
}