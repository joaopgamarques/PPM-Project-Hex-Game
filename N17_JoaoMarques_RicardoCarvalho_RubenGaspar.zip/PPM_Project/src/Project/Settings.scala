package Project

type Settings = (Difficulty, FirstPlayer, UserInterface)