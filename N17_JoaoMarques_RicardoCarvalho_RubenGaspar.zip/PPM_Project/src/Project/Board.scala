package Project

type Board = List[List[Cells.Cell]]