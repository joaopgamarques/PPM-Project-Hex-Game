package Project

enum GameOptions {
  case MainMenu, GameMenu, Settings
}