package Project

enum Difficulty {
  case Easy, Normal
}