package Project

enum UserInterface {
  case TUI, GUI // Text-based User Interface (TUI), Graphical User Interface(GUI)
}