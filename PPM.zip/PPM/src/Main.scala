import java.time.LocalDateTime
import scala.annotation.tailrec
import scala.collection.immutable.::
import scala.io.StdIn.readLine
import math.Ordering
import Tutorial.Rational

object Main {
  def main(args: Array[String]): Unit = {
    // println(mapReduce(x => x, (x, y) => x + y, 0)(1, 9))
    // println(sumMR(x => x)(1, 9))
    // println(scaleList(List(1,2,3,4),2))
    // println(squareList(List(1,2,3,4)))
    // println(positiveElements(List(-1,2,-2,1)))
    // println(concatFR(List(1,2,3), List(4,5)))
    // println(mapFun(List(1,2,3,4), x => x * 2))
    // println(mergeSortB(List(4,2,1,3))((x, y) => x < y))
    // println(mergeSortC(List(4,2,1,3))(Ordering.Int))
    // println(mergeSortD(List(4,2,1,3)))
    // val fruits = List("apple", "pear", "orange", "pineapple")
    // println(mergeSortB(fruits)((x: String, y: String) => x.compareTo(y) < 0))
    // println(List(4,2,1,3).map(x => byTen(x)))
    // println(sumList(List(1,2,3,4,5)))
    // val singleton: Tutorial.IntSet = Tutorial.IntSet.singleton(7)
    // println(Tutorial.NonEmptySet(7, Tutorial.EmptySet(), Tutorial.EmptySet()).contains(7))
    //bval date: Option[LocalDateTime] = Some(LocalDateTime.now())
    // if(date.isDefined) then println(date.get)
    val rational: Rational = Rational(2, 3)
  }

  def sumList(list: List[Int]): Int = {
    @tailrec
    def loop(list1: List[Int], acc: Int): Int = list1 match {
      case List() => acc
      case x :: xs => loop(xs, acc + x)
    }
    loop(list, 0)
  }
  
  def multiplier(i: Int)(factor: Int): Int = i * factor
  val byTen = multiplier(10)

  def mergeSortA(ls: List[Int]): List[Int] = {
    def merge(left: List[Int], right: List[Int]): List[Int] = (left, right) match {
      case (Nil, _) => right
      case (_, Nil) => left
      case (x :: xs, y :: ys) => if (x < y) then x :: merge(xs, right) else y :: merge(left, ys)
    }
    ls match {
      case Nil => Nil
      case List(x) => List(x)
      case _ =>
        val (left, right): (List[Int], List[Int]) = ls.splitAt(ls.length / 2)
        merge(mergeSortA(left), mergeSortA(right))
    }
  }

  def mergeSortB[T](ls: List[T])(lt: (T, T) => Boolean): List[T] = {
    def merge(left: List[T], right: List[T]): List[T] = (left, right) match {
      case (Nil, _) => right
      case (_, Nil) => left
      case (x :: xs, y :: ys) => if (lt(x, y)) then x :: merge(xs, right) else y :: merge(left, ys)
    }
    ls match {
      case Nil => Nil
      case List(x) => List(x)
      case _ =>
        val (left, right): (List[T], List[T]) = ls.splitAt(ls.length / 2)
        merge(mergeSortB(left)(lt), mergeSortB(right)(lt))
    }
  }

  def mergeSortC[T](ls: List[T])(order: Ordering[T]): List[T] = {
    def merge(left: List[T], right: List[T]): List[T] = (left, right) match {
      case (Nil, _) => right
      case (_, Nil) => left
      case (x :: xs, y :: ys) => if (order.lt(x, y)) then x :: merge(xs, right) else y :: merge(left, ys)
    }
    ls match {
      case Nil => Nil
      case List(x) => List(x)
      case _ =>
        val (left, right): (List[T], List[T]) = ls.splitAt(ls.length / 2)
        merge(mergeSortC(left)(order), mergeSortC(right)(order))
    }
  }

  def mergeSortD[T](ls: List[T])(implicit order: Ordering[T]): List[T] = {
    def merge(left: List[T], right: List[T]): List[T] = (left, right) match {
      case (Nil, _) => right
      case (_, Nil) => left
      case (x :: xs, y :: ys) => if (order.lt(x, y)) then x :: merge(xs, right) else y :: merge(left, ys)
    }

    ls match {
      case Nil => Nil
      case List(x) => List(x)
      case _ =>
        val (left, right): (List[T], List[T]) = ls.splitAt(ls.length / 2)
        merge(mergeSortD(left), mergeSortD(right))
    }
  }

  def mergeSortE[T](lt: (T, T) => Boolean)(ls: List[T]): List[T] = {
    def merge(left: List[T], right: List[T]): List[T] = (left, right) match {
      case (Nil, _) => right
      case (_, Nil) => left
      case (x :: xs, y :: ys) => if (lt(x, y)) then x :: merge(xs, right) else y :: merge(left, ys)
    }

    ls match {
      case Nil => Nil
      case List(x) => List(x)
      case _ =>
        val (left, right): (List[T], List[T]) = ls.splitAt(ls.length / 2)
        merge(mergeSortE(lt)(left), mergeSortE(lt)(right))
    }
  }

  val intSort = mergeSortE((x: Int, y: Int) => x < y) _

  // Reduce Left and Fold Left
  def sumListRL(xs: List[Int]): Int = (0::xs).reduceLeft(_ + _)
  def productListRL(xs: List[Int]): Int = (1::xs).reduceLeft(_ * _)
  def sumListFL(xs: List[Int]): Int = xs.foldLeft(0)(_ + _)
  def productList(xs: List[Int]): Int = xs.foldLeft(1)(_ * _)
  def concatFR[T](xs: List[T], ys: List[T]): List[T] = xs.foldRight(ys)(_ :: _)
  def reverseFL[T](xs: List[T]): List[T] = xs.foldLeft(List[T]())((xs, x) => x :: xs)
  def mapFun[T, U](xs: List[T], f: T => U): List[U] = xs.foldRight(List[U]())((y, ys) => f(y)::ys)
  def lengthFun[T](xs: List[T]): Int = xs.foldRight(0)((_, n) => n + 1)

  def removeAt[T](n: Int, xs: List[T]): List[T] = xs match {
    case Nil => Nil
    case y::ys =>
      if(n == 0) then ys else y::removeAt(n - 1, ys)
  }

  def flatten(xs: Any): List[Any] = xs match {
    case Nil => Nil
    case y::ys => flatten(y) ++ flatten(ys)
    case _ => xs::Nil
  }

  def pack[T](xs: List[T]): List[List[T]] = xs match {
    case Nil => Nil
    case y::ys => {
      val (more, rest) = xs.span(x => x == y)
      (y::more)::pack(rest)
    }
  }

  def encode[T](xs: List[T]): List[(T, Int)] = pack(xs).map(x => (x.head, x.length))

  // List mapping
  def scaleList(xs: List[Double], factor: Double): List[Double] = xs.map(x => x*factor)
  def squareList(xs: List[Int]): List[Int] = xs.map(x => x*x)

  // List filtering
  def positiveElements(xs: List[Int]): List[Int] = xs.filter(x => x > 0)

  // High-order functions
  def sum(f: Int => Int, a: Int, b: Int): Int = {
    if (a > b) then 0 else f(a) + sum(f, a + 1, b)
  }

  def sumFactorials(a: Int, b: Int): Int = sum(factorialR, a, b)
  def sumCubes(a: Int, b: Int): Int = sum(cube, a, b)
  def sumInts(a: Int, b: Int): Int = sum(id, a, b)

  def id(x: Int): Int = x
  def cube(x: Int): Int = Math.pow(x, 3).toInt
  def factorialR(x: Int): Int = if (x == 0) then 1 else x * factorialR(x - 1)

  // Anonymous functions
  def sumIntsA(a: Int, b: Int): Int = sum(x => x, a, b)
  def sumCubesA(a: Int, b: Int): Int = sum(x => Math.pow(x, 3).toInt, a, b)

  // High-order functions: tail recursion
  def sumR(f: Int => Int, a: Int, b: Int): Int = {
    @tailrec
    def loop(a: Int, acc: Int): Int = {
      if(a > b) then acc else loop(a + 1, acc + f(a))
    }
    loop(a, 0)
  }

  // High-order functions: currying
  def sumC(f: Int => Int): (Int, Int) => Int = {
    def sumF(a: Int, b: Int): Int = {
      if(a > b) then 0 else f(a) + sumF(a + 1, b)
    }
    sumF
  }

  def sumIntsC: (Int, Int) => Int = sumC(x => x)
  def sumCubesC: (Int, Int) => Int = sumC(x => Math.pow(x, 3).toInt)
  def sumFactorialsC: (Int, Int) => Int = sumC(factorialR)

  def sumMP(f: Int => Int)(a: Int, b: Int): Int = if(a > b) then 0 else f(a) + sumMP(f)(a + 1, b)
  def product(f: Int => Int)(a: Int, b: Int): Int = if(a > b) then 1 else f(a) * product(f)(a + 1, b)

  def factorial(n: Int): Int = product(id)(1, n)

  def mapReduce(f: Int => Int, combine: (Int, Int) => Int, c: Int)(a: Int, b: Int): Int = {
    def recur(a: Int): Int = {
      if (a > b) then c else combine(f(a), recur(a + 1))
    }
    recur(a)
  }

  def sumMR(f: Int => Int): (Int, Int) => Int = mapReduce(f, (x, y) => x + y, 0)
  def productMR(f: Int => Int): (Int, Int) => Int = mapReduce(f, (x, y) => x * y, 1)

  val tolerance = 0.0001

  def isCloseEnough(x: Double, y: Double): Boolean = Math.abs((x - y) / x) < tolerance

  def fixedPoint(f: Double => Double)(firstGuess: Double): Double = {
    @tailrec
    def iterate(guess: Double): Double = {
      val next = f(guess)
      if(isCloseEnough(guess, next)) then next else iterate(next)
    }
    iterate(firstGuess)
  }

  def sqrtR(x: Double): Double = fixedPoint(averageDamp(y => x / y))(1.0)

  def averageDamp(f: Double => Double)(x: Double): Double = (x + f(x)) / 2

  def getClassAsString(x: Matchable): String = x match
    case s: String => "String"
    case i: Int => "Integer"
    case d: Double => "Double"
    case l: List[?] => "List"
    case _ => "Unknown"

  def sum(a: Int, b: Int): Int = a + b

  def isPositive(n: Int): Boolean =
    return n >= 0

  def max(a: Int, b: Int): Int = if a >= b then a else b

  def square(x: Double): Double = x * x

  def abs(x: Double): Double = if x >= 0 then x else -x

  def sqrt(x: Double): Double = {
    @tailrec
    def sqrtIter(guess: Double): Double =
      if isGoodEnough(guess) then guess else sqrtIter(improve(guess))

    def improve(guess: Double): Double = (guess + x / guess) / 2

    def isGoodEnough(guess: Double): Boolean = abs(square(guess) - x) < 0.001

    sqrtIter(1.0)
  }
}



