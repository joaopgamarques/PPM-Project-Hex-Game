import scala.annotation.tailrec

object Exam extends App{

  private val listOfIntegers: List[Int] = List(1, 2, 5, 4, 6, 4, 2)
  println(getSumOfList(listOfIntegers))
  println(getSumOfListTailRecursive(listOfIntegers))
  println(getSumOfListFoldRight(listOfIntegers))
  println(getSumOfListFoldLeft(listOfIntegers))
  println(getSumOfListReduceRight(listOfIntegers))
  println(getSumOfListReduceLeft(listOfIntegers))

  private def getSumOfList(list: List[Int]): Int = list match {
    case Nil => 0
    case head :: tail => head + getSumOfList(tail)
  }

  private def getSumOfListTailRecursive(list: List[Int]): Int = {
    @tailrec
    def getSumOfListTailRecursiveHelper(innerList: List[Int], acc: Int): Int = innerList match {
      case Nil => acc
      case head :: tail => getSumOfListTailRecursiveHelper(tail, acc + head)
    }
    getSumOfListTailRecursiveHelper(list, 0)
  }

  private def getSumOfListFoldRight(list: List[Int]): Int = list.foldRight(0)((element, acc) => element + acc)

  private def getSumOfListFoldLeft(list: List[Int]): Int = list.foldLeft(0)((acc, element) => element + acc)

  private def getSumOfListReduceRight(list: List[Int]): Int = list.reduceRight((element, acc) => element + acc)

  private def getSumOfListReduceLeft(list: List[Int]): Int = list.reduceLeft((acc, element) => element + acc)

  val sum: (Int, Int) => Int = (x, y) => x + y
  val multiply: (Int, Int) => Int = (x, y) => x * y
  private def arithmeticOperation(a: Int, b: Int, function: (Int, Int) => Int): Int = function.apply(a, b)
  println(arithmeticOperation(2, 3, sum))
  println(arithmeticOperation(2, 3, multiply))

  // Partially Applied Functions
  private def calculateSellingPrice(discount: Double, productPrice: Double): Double = (1 - discount / 100) * productPrice
  private val discountApplied: Double => Double = calculateSellingPrice(25, _)
  private val sellingPrice: Double = discountApplied.apply(1000)
  assert(sellingPrice == 750)

  // Currying
  private def curriedSum(x: Int)(y: Int): Int = x + y
  private val curriedSum: Int => Int => Int = sum.curried

  private val addOne: Int => Int = (x: Int) => x + 1
  private val multiplyByTwo: Int => Int = (x: Int) => x * 2
  private val composedFunction: Int => Int = multiplyByTwo.compose(addOne)
  println(composedFunction(5))
  private val pipelinedFunction: Int => Int = addOne.andThen(multiplyByTwo)
  println(composedFunction(5))



}
