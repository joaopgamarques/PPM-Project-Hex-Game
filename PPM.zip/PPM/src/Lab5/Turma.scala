package Lab5
import Lab5.RegimeOPT.RegimeOPT
import Lab5.Turma.*
import scala.annotation.tailrec
import scala.collection.immutable.::

case class Turma(id: String, alunos: Alunos){
  def trabs: Alunos = Turma.trabs(this)
  def finalGrade(n: Numero): Option[Float] = Turma.finalGrade(n, this)
  def approved: List[(Nome, Float)] = Turma.approved(this)
  def changeNP(n: Numero, np: NP): Turma = Turma.changeNP(n, np, this)
  def insertOrd(a: Aluno): Turma = Turma.insertOrd(a, this)
  def insertOrd1(a: Aluno): Turma = Turma.insertOrd1(a, this)
  def searchStudentOrd1(n: Numero): Option[Aluno] = Turma.searchStudentOrd1(n, this)
}

object Turma {
  type Nome = String
  type Numero = Int
  type NT = Option[Float]
  type NP = Option[Float]
  type Regime = RegimeOPT
  type Aluno = (Numero, Nome, Regime, NT, NP)
  type Alunos = List[Aluno]

  def trabs(t: Turma): Alunos = {
    t.alunos.filter(x => x._3.equals(RegimeOPT.TrabEstud))
  }

  def trabs1(t: Turma): Alunos = {
    def loop(l: Alunos): Alunos = l match {
      case Nil => Nil
      case x::xs => if(x._3.equals(RegimeOPT.TrabEstud)) then x::loop(xs) else loop(xs)
    }
    loop(t.alunos)
  }

  def searchStudent(t: Alunos, n: Numero): Option[Aluno] = {
    t.foldRight(None: Option[Aluno])((x: Aluno, xs) =>
      if(x._1 == n) then Some(x) else xs
    )
  }

  @tailrec
  def searchStudent1(t: Alunos, n: Numero): Option[Aluno] = t match {
    case Nil => None
    case x::xs => if(x._1 == n) then Some(x) else searchStudent1(xs, n)
  }

  def finalGrade(n: Numero, t: Turma): Option[Float] = {
    val a1: Option[Aluno] = searchStudent(t.alunos, n)
    if(a1.isDefined) {
      if(a1.get._4.isDefined && a1.get._5.isDefined && a1.get._4.get >= 9.5 && a1.get._5.get >= 9.5) {
        Some(a1.get._4.get * 0.6.toFloat + a1.get._5.get * 0.4.toFloat)
      } else {
        None
      }
    } else {
      None
    }
  }

  def finalGrade1(n: Numero, t: Turma): Option[Float] = {
    val index: Int = t.alunos.indexWhere(x => x._1 == n)
    if(index != -1) {
      val a1 = t.alunos.apply(index)
      if (a1._4.isDefined && a1._5.isDefined && a1._4.get >= 9.5 && a1._5.get >= 9.5) {
        Some(a1._4.get * 0.6.toFloat + a1._5.get * 0.4.toFloat)
      } else {
        None
      }
    } else {
      None
    }
  }

  def approved(t: Turma): List[(Nome, Float)] = {
    t.alunos.foldRight(List[(Nome, Float)]())((x: Aluno, xs) => {
      val grade: Option[Float] = finalGrade(x._1, t)
      if (grade.isDefined && grade.get >= 10) then (x._2, grade.get) :: xs else xs
    })
  }

  def changeNP(n: Numero, np: NP, t: Turma): Turma = {
    val index = t.alunos.indexWhere(x => x._1 == n)
    if(index != -1) {
      val a: Aluno = t.alunos.apply(index)
      val a1: Aluno = (a._1, a._2, a._3, a._4, np)
      val t1: Turma = new Turma(t.id, t.alunos.updated(index, a1))
      t1
    } else {
      t
    }
  }

  def changeNT(n: Numero, nt: NT, t: Turma): Turma = {
    val index = t.alunos.indexWhere(x => x._1 == n)
    if (index != -1) {
      val a: Aluno = t.alunos.apply(index)
      val a1: Aluno = (a._1, a._2, a._3, nt, a._5)
      val t1: Turma = new Turma(t.id, t.alunos.updated(index, a1))
      t1
    } else {
      t
    }
  }

  def insertOrd(a:Aluno, t:Turma) : Turma = {
    Turma(t.id, t.alunos.foldRight(List[Aluno](a))((x: Aluno, xs) => {
      if (a._1 < x._1) then a::x::xs else x::xs
    }))
  }

  def insertOrd1(a:Aluno, t:Turma) : Turma = {
    def loop(t1: Alunos): Alunos = t1 match {
      case Nil => List(a)
      case x::xs => if(a._1 < x._1) then a::x::xs else x::loop(xs)
    }
    Turma(t.id, loop(t.alunos))
  }

  def searchStudentOrd1(n: Numero, t1: Turma): Option[Aluno] = {
    @tailrec
    def loop(t: Alunos): Option[Aluno] = t match {
      case Nil => None
      case x::xs => if(x._1 == n) then Some(x) else loop(xs)
    }
    loop(t1.alunos)
  }

}