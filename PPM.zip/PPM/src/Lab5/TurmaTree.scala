package Lab5
import Lab5.RegimeOPT.RegimeOPT
import Lab5.TurmaTree.{Aluno, Alunos, NP, NT, Nome, Numero, Regime}
import scala.annotation.tailrec
import scala.collection.immutable.::

case class TurmaTree(id: String, alunos: Alunos){
  def trabsTree: List[Aluno] = TurmaTree.trabsTree(this.alunos)
  def searchStudentTree(n: Numero): Option[Aluno] = TurmaTree.searchStudentTree(n, this.alunos)
  def finalGradeTree(n: Numero): Option[Float] = TurmaTree.finalGradeTree(n, this.alunos)
  def approvedTree: List[(Nome, Float)] = TurmaTree.approvedTree(this.alunos)
  def changeNPTree(n: Numero, np: NP): MyTree[Aluno] = TurmaTree.changeNPTree(n, np, this.alunos)
  def changeNTTree(n: Numero, nt: NT): MyTree[Aluno] = TurmaTree.changeNTTree(n, nt, this.alunos)
  def insertTree(a: Aluno): MyTree[Aluno] = TurmaTree.insertTree(a, this.alunos)
}

object TurmaTree {
  type Nome = String
  type Numero = Int
  type NT = Option[Float]
  type NP = Option[Float]
  type Regime = RegimeOPT
  type Aluno = (Numero, Nome, Regime, NT, NP)
  type Alunos = MyTree[Aluno]

  def trabsTree(t: MyTree[Aluno]): List[Aluno] = t match {
    case Empty => Nil
    case Node(a, left, right) =>
      if(a._3 == RegimeOPT.TrabEstud) then a::trabsTree(left)++trabsTree(right) else trabsTree(left)++trabsTree(right)
  }

  @tailrec
  def searchStudentTree(n:Numero, t:MyTree[Aluno]): Option[Aluno]= t match {
    case Empty => None
    case Node(a, left, right) =>
      if(n < a._1) then searchStudentTree(n, left) else if(n > a._1) then searchStudentTree(n, right) else Some(a)
  }

  @tailrec
  def finalGradeTree(n: Numero, t:MyTree[Aluno]): Option[Float] = t match {
    case Empty => None
    case Node(a, left, right) =>
      if(n < a._1) {
        finalGradeTree(n, left)
      } else if(n > a._1) {
        finalGradeTree(n, right)
      } else if(a._4.isDefined && a._5.isDefined && a._4.get >= 9.5 && a._5.get >= 9.5) {
        Some(a._4.get * 0.6.toFloat + a._5.get * 0.4.toFloat)
      } else {
        None
      }
  }

  def approvedTree(t: MyTree[Aluno]): List[(Nome,Float)] = t match {
    case Empty => Nil
    case Node(a, left, right) =>
      val grade: Option[Float] = finalGradeTree(a._1, t)
      if(grade.isDefined && grade.get >= 10) then (a._2, grade.get) :: approvedTree(left) ++ approvedTree(right)
      else approvedTree(left) ++ approvedTree(right)
  }

  def changeNPTree(n: Numero, np: NP, t: MyTree[Aluno]): MyTree[Aluno] = t match {
    case Empty => Empty
    case Node(a, left, right) =>
      if (n < a._1) {
        Node(a, changeNPTree(n, np, left), right)
      } else if (n > a._1) {
        Node(a, left, changeNPTree(n, np, right))
      } else {
        Node((a._1,a._2,a._3,a._4,np), left, right)
      }
  }

  def changeNTTree(n: Numero, nt: NT, t: MyTree[Aluno]): MyTree[Aluno] = t match {
    case Empty => Empty
    case Node(a, left, right) =>
      if (n < a._1) {
        Node(a, changeNPTree(n, nt, left), right)
      } else if (n > a._1) {
        Node(a, left, changeNPTree(n, nt, right))
      } else {
        Node((a._1, a._2, a._3, nt, a._5), left, right)
      }
  }

  def insertTree(a: Aluno, t:MyTree[Aluno]):MyTree[Aluno] =  t match {
      case Empty => Node(a,Empty, Empty)
      case Node(v, left, right) =>
        if(a._1 < v._1)
          Node(v, left, insertTree(a, right))
        else if (a._1 > v._1)
          Node(v, insertTree(a,left),right)
        else
          t
  }
}