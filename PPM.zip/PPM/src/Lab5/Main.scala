package Lab5

object Main {
  def main(args: Array[String]): Unit = {
    val t: Turma = Turma("id22", List((11, "João", RegimeOPT.Ordinario, Some(10), Some(20)),
      (12, "José", RegimeOPT.TrabEstud, Some(13), None),
      (13, "David", RegimeOPT.TrabEstud, Some(11), Some(14))))
    println("Workers-students: " + t.trabs)

    val t1: TurmaTree = TurmaTree("id22", Node((11, "João", RegimeOPT.Ordinario, Some(10), Some(20)),
      Node((12, "José", RegimeOPT.TrabEstud, Some(13), None), Empty, Empty),
      Node((13, "David", RegimeOPT.TrabEstud, Some(11), Some(14)), Empty, Empty)))
    println("Workers-students: " + t1.trabsTree)
  }
}