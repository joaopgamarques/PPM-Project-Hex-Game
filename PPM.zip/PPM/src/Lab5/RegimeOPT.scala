package Lab5

object RegimeOPT extends Enumeration {
  type RegimeOPT = Value
  val Ordinario, TrabEstud = Value
}
 
