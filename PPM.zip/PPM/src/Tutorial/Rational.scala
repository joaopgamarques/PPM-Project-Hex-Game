package Tutorial

import scala.annotation.{tailrec, targetName}
import scala.language.implicitConversions

class Rational(x: Int, y: Int):
  require(y > 0, "Denominator must be positive.")
  def this(x: Int) = this(x, 1)

  @tailrec
  private def gcd(a: Int, b:Int): Int = if b == 0 then a else gcd(b, a % b)
  val numerator: Int = x / gcd(x.abs, y)
  val denominator: Int = y / gcd(x.abs, y)

  def add(r: Rational): Rational =
    Rational(numerator * r.denominator + r.numerator * denominator, denominator * r.denominator)
  def multiply(r: Rational): Rational =
    Rational(numerator + r.numerator, denominator * r.denominator)
  def negate: Rational = Rational(-numerator, denominator)
  def substract(r: Rational): Rational = add(r.negate)

  override def toString: String = s"$numerator/$denominator"

  override def equals(other: Any): Boolean = other match {
    case that: Rational => this.canEqual(that) && numerator == that.numerator && denominator == that.denominator
    case _ => false
  }
  private def canEqual(other: Any): Boolean = other.isInstanceOf[Rational]

  def isLessThan(that: Rational): Boolean =
    numerator * that.denominator < that.numerator * denominator
  def max(that: Rational): Rational = if(isLessThan(that)) then that else this
end Rational

extension(r: Rational)
  def min(s: Rational): Rational = if s.isLessThan(r) then s else r
  def abs: Rational = Rational(r.numerator.abs, r.denominator)
  @targetName("addition")
  def +(s: Rational): Rational = r.add(s)
  def +(i: Int): Rational = new Rational(r.numerator + i * r.denominator, r.denominator)
  @targetName("multiplication")
  def *(s: Rational): Rational = s.multiply(s)

object Rational:
  implicit def intToRational(x: Int): Rational = Rational(x)
  def main(args: Array[String]): Unit = {
    val a: Rational = new Rational(2, 3)
    println(2 + a)
  }
end Rational