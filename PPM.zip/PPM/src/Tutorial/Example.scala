package Tutorial

sealed trait MyTree[+A]
case object Empty extends MyTree[Nothing]
case class Node[A](value: A, left: MyTree[A], right: MyTree[A]) extends MyTree[A]

case class Example(myField: MyTree[Int]) {
  def size(): Int = Example.size(this.myField)
}

object Example {
  def size[A](t: MyTree[A]): Int = t match {
    case Empty => 0
    case Node(value, left, right) => 1 + size(left) + size(right)
  }

  def main(args: Array[String]): Unit = {
    val tree1 = Node(42, Node(4, Empty, Empty), Node(84, Empty, Empty))
    val e = Example(tree1)
    println(s"Number of nodes of the tree: ${e.size()}")
  }
}
