package Tutorial

class EmptySet() extends IntSet {
  def include(x: Int): IntSet = NonEmptySet(x, EmptySet(), EmptySet())
  def contains(x: Int): Boolean = false
  def union(s: IntSet): IntSet = s
}
