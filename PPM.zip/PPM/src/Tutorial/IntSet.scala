package Tutorial

abstract class IntSet {
  def include(x: Int): IntSet
  def contains(x: Int): Boolean
  def union(s: IntSet): IntSet
}

object IntSet {
  def singleton(x: Int): IntSet = NonEmptySet(x, EmptySet(), EmptySet())
  def apply(): IntSet = EmptySet()
  def apply(x: Int): IntSet = EmptySet().include(x)
  def apply(x: Int, y: Int): IntSet = EmptySet().include(x).include(y)
}