package Tutorial

class NonEmptySet(element: Int, left: IntSet, right: IntSet) extends IntSet {
  def include(x: Int): IntSet = {
    if (x < element) then NonEmptySet(element, left.include(x), right)
    else if (x > element) then NonEmptySet(element, left, right.include(x))
    else this
  }

  def contains(x: Int): Boolean = {
    if (x < element) then left.contains(x)
    else if (x > element) then right.contains(x)
    else true
  }

  def union(s: IntSet): IntSet = left.union(right).union(s).include(element)
}

object Main extends App {
  println("Hello World!")
}
