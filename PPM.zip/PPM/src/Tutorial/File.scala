package Tutorial

 trait Random {
   def nextInt(x: Int): (Int, Random)
 }

case class MyRandom(seed: Long) extends Random {
  override def nextInt(x: Int): (Int, Random) = {
    val newSeed = (seed * 0x5DEECE66DL + 0xBL) & 0xFFFFFFFFFFFFL
    val nextRandom: MyRandom = MyRandom(newSeed)
    val n = ((newSeed >>> 16).toInt) % x
    (math.abs(n), nextRandom)
  }
}

object Start extends App {
  val seed: Int = 10
  val (n1, r1) = MyRandom(seed).nextInt(100)
  val(n2, r2) = r1.nextInt(100)
  println(n1 + " " + n2)
}